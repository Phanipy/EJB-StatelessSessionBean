package com.controller;

import javax.faces.bean.ManagedBean;

import com.model.Calculator;

@ManagedBean
public class Calc {
	
			int a, b, c;
			//setters and getters
			
			Calculator cr=new Calculator();
			
			public int getA() {
				return a;
			}
			public void setA(int a) {
				this.a = a;
			}
			public int getB() {
				return b;
			}
			public void setB(int b) {
				this.b = b;
			}
			public int getC() {
				return c;
			}
			public void setC(int c) {
				this.c = c;
			}
			public void callAdd(){ c=cr.add(a,b);}
			public void callSub(){ c=cr.sub(a,b);}
			

}
